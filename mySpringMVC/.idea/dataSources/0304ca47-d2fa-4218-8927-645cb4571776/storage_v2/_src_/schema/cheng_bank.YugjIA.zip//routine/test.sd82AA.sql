create
  definer = root@localhost procedure test()
BEGIN

declare i int default 1;

while i < 71 DO

  insert into t_student(stu_name,stu_sex,stu_status,tea_id) values(CONCAT('学生',i ),0,1,7);

  set i = i + 1;

end while;

end;

