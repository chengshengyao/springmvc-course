create
  definer = root@localhost procedure teacher()
BEGIN

declare i int default 1;

while i < 71 DO

  insert into t_teacher(tea_name,tea_age,tea_sex,tea_date) values(CONCAT('教师',i ),26,1,NOW());

  set i = i + 1;

end while;

end;

